# Fangyuan Wan
# A dodgeball team management system

class Player:
    """
    A class representing a dodgeball player
    """
    def __init__(self, name, number, position):
        self.name = name
        self.number = number
        self.position = position
